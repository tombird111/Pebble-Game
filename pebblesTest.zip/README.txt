The suite may be run on an IDE using JUnit 4 by running a test on TestSuite
The suite will run all tests and some additional information will be printed to the command line