import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestPebbles.class,
	TestPebbleBag.class
	})
public class TestSuite {

}
